package models;

public enum MilitaryType {
    FIGHTER, BOMBER, TRANSPORT
}
