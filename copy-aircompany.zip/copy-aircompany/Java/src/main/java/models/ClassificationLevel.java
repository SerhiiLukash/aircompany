package models;

public enum ClassificationLevel {
    UNCLASSIFIED, CONFIDENTIAL, SECRET, TOP_SECRET
}
