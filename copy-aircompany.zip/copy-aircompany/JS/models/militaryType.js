const MilitaryType = {
    TYPE_FIGHTER: 'Fighter',
    TYPE_BOMBER: 'Bomber',
    TYPE_TRANSPORT: 'Transport'
};

module.exports =  MilitaryType;
